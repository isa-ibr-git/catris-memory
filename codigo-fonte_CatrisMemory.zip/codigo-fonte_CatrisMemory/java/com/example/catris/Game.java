package com.example.catris;

public class Game {
    private int idGame;
    private String tipo;

    public Game(int idGame, String tipo) {
        this.idGame = idGame;
        this.tipo = tipo;
    }

    public int getIdGame() {
        return idGame;
    }

    public void setIdGame(int idGame) {
        this.idGame = idGame;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    @Override
    public String toString() {
        return "Game{" +
                "idGame=" + idGame +
                ", tipo='" + tipo + '\'' +
                '}';
    }
}
