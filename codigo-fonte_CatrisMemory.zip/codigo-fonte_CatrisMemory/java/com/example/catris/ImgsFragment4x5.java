package com.example.catris;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.fragment.app.Fragment;

import java.util.Arrays;
import java.util.Collections;
import java.util.Timer;
import java.util.TimerTask;

public class ImgsFragment4x5 extends Fragment {
    private DadosFragment dadosFragment;
    private Drawable dr;
    private Cursor cursor;
    private Game game;
    private UserJoga userJoga;
    private TextView p1, p2, res;

    // -------------- contagem -------------
    double tempo = 0.0;
    private Timer tm;
    private int cont = 0;
    private boolean rodando = false;
    private int hrs, min, seg;

    private int soma = 0;

    //----------JOGO 4 x 5 ---------------

    Game g = new Game(1, "4x5");
    String nome = "";
    int idGame;
    int melhorTempo;
    String cmd="";


    //------------------------------------

    SQLiteDatabase bd;

    //definindo variaveis p/ recuperar peças e pontuaçoes
    private TextView lvl, scr, tempoGame, bestTimes;
    private ImageView iv_11, iv_12, iv_13, iv_14, iv_21, iv_22, iv_23, iv_24, iv_31, iv_32, iv_33, iv_34,
            iv_41, iv_42, iv_43, iv_44, iv_51, iv_52, iv_53, iv_54;


    //lista das imagens
    Integer[] cartas = {101, 102, 103, 104, 105, 106, 107, 108, 109, 110,
            201, 202, 203, 204, 205, 206, 207, 208, 209, 210};

    //imagens atuais
    int img101, img102, img103, img104, img105, img106, img107, img108, img109, img110,
            img201, img202, img203, img204, img205, img206, img207, img208, img209, img210;


    //dados para inicio de jogo
    int carta1, carta2, clique1, clique2;
    int NumCarta = 1, acerto = 1, Seuspontos = 0, pontosPc = 0;


    //bd = openOrCreateDatabase("catrisMemoryDB", MODE_PRIVATE, null);

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);


    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        //definindo o timer

        Toast.makeText(getContext(), nome + ", " + idGame + ", " + melhorTempo + "!", Toast.LENGTH_LONG);


        View view = inflater.inflate(R.layout.imgs_5x4, container, false);

        //recuperando variaveis 4X3
        lvl = view.findViewById(R.id.txtLevel2);
        scr = view.findViewById(R.id.txtScore);
        bestTimes = view.findViewById(R.id.txtMelhorTempo);
        p1 = view.findViewById(R.id.player1);
        p2 = view.findViewById(R.id.player2);
        res = view.findViewById(R.id.txtResult);

        //iniciando com o player 1
        p1.setTextColor(Color.RED);
        p2.setTextColor(Color.BLACK);

        tempoGame = view.findViewById(R.id.txtTempo);
        tempoGame.setText("00:00:00"); //default
        scr.setText("");

        chamaCronometro(); //chamando conometro


        iv_11 = view.findViewById(R.id.iv_11);
        iv_12 = view.findViewById(R.id.iv_12);
        iv_13 = view.findViewById(R.id.iv_13);
        iv_14 = view.findViewById(R.id.iv_14);

        iv_21 = view.findViewById(R.id.iv_21);
        iv_22 = view.findViewById(R.id.iv_22);
        iv_23 = view.findViewById(R.id.iv_23);
        iv_24 = view.findViewById(R.id.iv_24);

        iv_31 = view.findViewById(R.id.iv_31);
        iv_32 = view.findViewById(R.id.iv_32);
        iv_33 = view.findViewById(R.id.iv_33);
        iv_34 = view.findViewById(R.id.iv_34);

        iv_41 = view.findViewById(R.id.iv_41);
        iv_42 = view.findViewById(R.id.iv_42);
        iv_43 = view.findViewById(R.id.iv_43);
        iv_44 = view.findViewById(R.id.iv_44);

        iv_51 = view.findViewById(R.id.iv_51);
        iv_52 = view.findViewById(R.id.iv_52);
        iv_53 = view.findViewById(R.id.iv_53);
        iv_54 = view.findViewById(R.id.iv_54);

        //definido tags p/ identificacao no clique
        iv_11.setTag("0");
        iv_12.setTag("1");
        iv_13.setTag("2");
        iv_14.setTag("3");

        iv_21.setTag("4");
        iv_22.setTag("5");
        iv_23.setTag("6");
        iv_24.setTag("7");

        iv_31.setTag("8");
        iv_32.setTag("9");
        iv_33.setTag("10");
        iv_34.setTag("11");

        iv_41.setTag("12");
        iv_42.setTag("13");
        iv_43.setTag("14");
        iv_44.setTag("15");

        iv_51.setTag("16");
        iv_52.setTag("17");
        iv_53.setTag("18");
        iv_54.setTag("19");

        lvl.setText("Nível Médio (4x5)"); //exibe nivel escolhido
        CarregaCartas();

        //metodo p/ embaralhar as cartas
        Collections.shuffle(Arrays.asList(cartas));

        //---------------coluna 1 ----------------

        iv_11.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int carta = Integer.parseInt((String) view.getTag());
                doS(iv_11, carta);

            }
        });
        iv_12.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int carta = Integer.parseInt((String) view.getTag());
                doS(iv_12, carta);

            }
        });
        iv_13.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int carta = Integer.parseInt((String) view.getTag());
                doS(iv_13, carta);

            }
        });
        iv_14.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int carta = Integer.parseInt((String) view.getTag());
                doS(iv_14, carta);

            }
        });


        //---------------coluna 2 ----------------

        iv_21.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int carta = Integer.parseInt((String) view.getTag());
                doS(iv_21, carta);
            }
        });




        iv_22.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int carta = Integer.parseInt((String) view.getTag());
                doS(iv_22, carta);

            }
        });


        iv_23.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int carta = Integer.parseInt((String) view.getTag());
                doS(iv_23, carta);

            }
        });
        iv_24.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int carta = Integer.parseInt((String) view.getTag());
                doS(iv_24, carta);
            }
        });


        //---------------coluna 3 ----------------

        iv_31.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int carta = Integer.parseInt((String) view.getTag());
                doS(iv_31, carta);
            }
        });
        iv_32.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int carta = Integer.parseInt((String) view.getTag());
                doS(iv_32, carta);
            }
        });
        iv_33.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int carta = Integer.parseInt((String) view.getTag());
                doS(iv_33, carta);
            }
        });
        iv_34.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int carta = Integer.parseInt((String) view.getTag());
                doS(iv_34, carta);
            }
        });

        //---------------coluna 4 ----------------

        iv_41.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int carta = Integer.parseInt((String) view.getTag());
                doS(iv_41, carta);
            }
        });
        iv_42.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int carta = Integer.parseInt((String) view.getTag());
                doS(iv_42, carta);
            }
        });
        iv_43.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int carta = Integer.parseInt((String) view.getTag());
                doS(iv_43, carta);
            }
        });
        iv_44.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int carta = Integer.parseInt((String) view.getTag());
                doS(iv_44, carta);
            }
        });

        //---------------coluna 5 ----------------

        iv_51.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int carta = Integer.parseInt((String) view.getTag());
                doS(iv_51, carta);
            }
        });
        iv_52.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int carta = Integer.parseInt((String) view.getTag());
                doS(iv_52, carta);
            }
        });
        iv_53.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int carta = Integer.parseInt((String) view.getTag());
                doS(iv_53, carta);
            }
        });
        iv_54.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int carta = Integer.parseInt((String) view.getTag());
                doS(iv_54, carta);
            }
        });



        return view;
      }

    private void doS(ImageView iv, int carta) {

        //função p/ definir a carta correta

        if (cartas[carta] == 101) {
            iv.setImageResource(img101);

        } else if (cartas[carta] == 102) {
            iv.setImageResource(img102);

        } else if (cartas[carta] == 103) {
            iv.setImageResource(img103);

        } else if (cartas[carta] == 104) {
            iv.setImageResource(img104);

        } else if (cartas[carta] == 105) {
            iv.setImageResource(img105);

        } else if (cartas[carta] == 106) {
            iv.setImageResource(img106);

        } else if(cartas[carta] == 107){
            iv.setImageResource(img107);

        }else if(cartas[carta] == 108){
            iv.setImageResource(img108);

        }else if(cartas[carta] == 109){
            iv.setImageResource(img109);

        }else if(cartas[carta] == 110){
            iv.setImageResource(img110);
        }
        //-------------------
        else if (cartas[carta] == 201) {
            iv.setImageResource(img201);

        } else if (cartas[carta] == 202) {
            iv.setImageResource(img202);

        } else if (cartas[carta] == 203) {
            iv.setImageResource(img203);

        } else if (cartas[carta] == 204) {
            iv.setImageResource(img204);

        } else if (cartas[carta] == 205) {
            iv.setImageResource(img205);

        } else if (cartas[carta] == 206) {
            iv.setImageResource(img206);

        } else if(cartas[carta] == 207){
            iv.setImageResource(img207);

        }else if(cartas[carta] == 208){
            iv.setImageResource(img208);

        }else if(cartas[carta] == 209){
            iv.setImageResource(img209);

        }else if(cartas[carta] == 210){
            iv.setImageResource(img210);
        }

        //ver qual img foi selecionada e salvar
        if(NumCarta == 1){
            carta1 = cartas[carta];
            if(carta1 > 200){
                carta1 = carta1 - 100;

            }

            NumCarta = 2;
            clique1 = carta;

            iv.setEnabled(false);

        }else if(NumCarta == 2){
            carta2 = cartas[carta];
            if(carta2 > 200){
                carta2 = carta2 - 100;
            }

            NumCarta = 1;
            clique2 = carta;

            iv_11.setEnabled(false);
            iv_12.setEnabled(false);
            iv_13.setEnabled(false);
            iv_14.setEnabled(false);

            iv_21.setEnabled(false);
            iv_22.setEnabled(false);
            iv_23.setEnabled(false);
            iv_24.setEnabled(false);

            iv_31.setEnabled(false);
            iv_32.setEnabled(false);
            iv_33.setEnabled(false);
            iv_34.setEnabled(false);

            iv_41.setEnabled(false);
            iv_42.setEnabled(false);
            iv_43.setEnabled(false);
            iv_44.setEnabled(false);

            iv_51.setEnabled(false);
            iv_52.setEnabled(false);
            iv_53.setEnabled(false);
            iv_54.setEnabled(false);

            Handler handler = new Handler();
            handler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    //ver se as imgs selecionadas sao iguais
                    calculo();
                }
            }, 1000);

        }
    }

    private void calculo(){



        //se ambas forem iguais, remove e add +1pt
        if(carta1 == carta2){

            //------------------------- primeiro clique  ------------------
            if(clique1 == 0){
                iv_11.setVisibility(View.INVISIBLE);

            }else if(clique1 == 1){
                iv_12.setVisibility(View.INVISIBLE);

            } else if(clique1 == 2){
                iv_13.setVisibility(View.INVISIBLE);

            }else if(clique1 == 3){
                iv_14.setVisibility(View.INVISIBLE);

            }else if(clique1 == 4){
                iv_21.setVisibility(View.INVISIBLE);

            }else if(clique1 == 5){
                iv_22.setVisibility(View.INVISIBLE);

            }else if(clique1 == 6){
                iv_23.setVisibility(View.INVISIBLE);

            }else if(clique1 == 7){
                iv_24.setVisibility(View.INVISIBLE);

            }else if(clique1 == 8){
                iv_31.setVisibility(View.INVISIBLE);

            }else if(clique1 == 9){
                iv_32.setVisibility(View.INVISIBLE);

            }else if(clique1 == 10){
                iv_33.setVisibility(View.INVISIBLE);

            }else if(clique1 == 11){
                iv_34.setVisibility(View.INVISIBLE);

            }else if(clique1 == 12){
                iv_41.setVisibility(View.INVISIBLE);
            }

            else if(clique1 == 13){
                iv_42.setVisibility(View.INVISIBLE);
            }

            else if(clique1 == 14){
                iv_43.setVisibility(View.INVISIBLE);
            }

            else if(clique1 == 15){
                iv_44.setVisibility(View.INVISIBLE);
            }

            else if(clique1 == 16){
                iv_51.setVisibility(View.INVISIBLE);
            }

            else if(clique1 == 17){
                iv_52.setVisibility(View.INVISIBLE);
            }

            else if(clique1 == 18){
                iv_53.setVisibility(View.INVISIBLE);
            }

            else if(clique1 == 19){
                iv_54.setVisibility(View.INVISIBLE);
            }

            //------------------------- segundo clique  ------------------
            if(clique2 == 0){
                iv_11.setVisibility(View.INVISIBLE);

            }else if(clique2 == 1){
                iv_12.setVisibility(View.INVISIBLE);

            } else if(clique2 == 2){
                iv_13.setVisibility(View.INVISIBLE);

            }else if(clique2 == 3){
                iv_14.setVisibility(View.INVISIBLE);

            }else if(clique2 == 4){
                iv_21.setVisibility(View.INVISIBLE);

            }else if(clique2 == 5){
                iv_22.setVisibility(View.INVISIBLE);

            }else if(clique2 == 6){
                iv_23.setVisibility(View.INVISIBLE);

            }else if(clique2 == 7){
                iv_24.setVisibility(View.INVISIBLE);

            }else if(clique2 == 8){
                iv_31.setVisibility(View.INVISIBLE);

            }else if(clique2 == 9){
                iv_32.setVisibility(View.INVISIBLE);

            }else if(clique2 == 10){
                iv_33.setVisibility(View.INVISIBLE);

            }else if(clique2 == 11){
                iv_34.setVisibility(View.INVISIBLE);

            }else if(clique2 == 12){
                iv_41.setVisibility(View.INVISIBLE);
            }

            else if(clique2 == 13){
                iv_42.setVisibility(View.INVISIBLE);
            }

            else if(clique2 == 14){
                iv_43.setVisibility(View.INVISIBLE);
            }

            else if(clique2 == 15){
                iv_44.setVisibility(View.INVISIBLE);
            }

            else if(clique2 == 16){
                iv_51.setVisibility(View.INVISIBLE);
            }

            else if(clique2 == 17){
                iv_52.setVisibility(View.INVISIBLE);
            }

            else if(clique2 == 18){
                iv_53.setVisibility(View.INVISIBLE);
            }

            else if(clique2 == 19){
                iv_54.setVisibility(View.INVISIBLE);
            }

            //add pt pro jogador que acertou
            if(acerto == 1){
                Seuspontos++;
                p1.setText("Você: " + Seuspontos);
            }else if(acerto == 2){
                pontosPc++;
                p2.setText("Adversário: " + pontosPc);
            }
        }else{
            iv_11.setImageResource(R.drawable.img_geral);
            iv_12.setImageResource(R.drawable.img_geral);
            iv_13.setImageResource(R.drawable.img_geral);
            iv_14.setImageResource(R.drawable.img_geral);

            iv_21.setImageResource(R.drawable.img_geral);
            iv_22.setImageResource(R.drawable.img_geral);
            iv_23.setImageResource(R.drawable.img_geral);
            iv_24.setImageResource(R.drawable.img_geral);

            iv_31.setImageResource(R.drawable.img_geral);
            iv_32.setImageResource(R.drawable.img_geral);
            iv_33.setImageResource(R.drawable.img_geral);
            iv_34.setImageResource(R.drawable.img_geral);

            iv_41.setImageResource(R.drawable.img_geral);
            iv_42.setImageResource(R.drawable.img_geral);
            iv_43.setImageResource(R.drawable.img_geral);
            iv_44.setImageResource(R.drawable.img_geral);

            iv_51.setImageResource(R.drawable.img_geral);
            iv_52.setImageResource(R.drawable.img_geral);
            iv_53.setImageResource(R.drawable.img_geral);
            iv_54.setImageResource(R.drawable.img_geral);

            //trocando a vez de cada jogador
            if(acerto == 1){
                acerto = 2;
                //vez do palyer 1
                p1.setTextColor(Color.BLACK);
                p2.setTextColor(Color.RED);

            }else if(acerto == 2){
                acerto = 1;
                //vez do palyer 2
                p2.setTextColor(Color.BLACK);
                p1.setTextColor(Color.RED);

            }
        }

        iv_11.setEnabled(true);
        iv_12.setEnabled(true);
        iv_13.setEnabled(true);
        iv_14.setEnabled(true);

        iv_21.setEnabled(true);
        iv_22.setEnabled(true);
        iv_23.setEnabled(true);
        iv_24.setEnabled(true);

        iv_31.setEnabled(true);
        iv_32.setEnabled(true);
        iv_33.setEnabled(true);
        iv_34.setEnabled(true);


        iv_41.setEnabled(true);
        iv_42.setEnabled(true);
        iv_43.setEnabled(true);
        iv_44.setEnabled(true);


        iv_51.setEnabled(true);
        iv_52.setEnabled(true);
        iv_53.setEnabled(true);
        iv_54.setEnabled(true);

        //ver se o jogo terminou

        fimGame();


    }


        //metodos do cronometro ---------------------------


    public void chamaCronometro(){
        if(!rodando){
            rodando = true;
            tm = new Timer();
            tm.scheduleAtFixedRate(new TimerTask() {
                @Override
                public void run() {
                    cont++;

                    seg = cont % 60;
                    min = cont / 60;
                    hrs = min / 60;

                    min %= 60;

                    tempoGame.setText(String.format("%02d:%02d:%02d", hrs, min, seg));
                    //formata com num inteiro c/ 2 digitos p/ exibir na tela
                }

            }, 500, 500);
        }



    }

    //---------------------------------------------------

    private void mostraRes(){
        cmd = "Seus pontos: "+ Seuspontos + " --- ";
        cmd += "Pontos Adversário: " + pontosPc;
        scr.setText(cmd);

    }

    private void fimGame(){

        String frase = "";
        if (iv_11.getVisibility() == View.INVISIBLE && iv_12.getVisibility() == View.INVISIBLE &&
                iv_13.getVisibility() == View.INVISIBLE && iv_14.getVisibility() == View.INVISIBLE &&
                iv_21.getVisibility() == View.INVISIBLE && iv_22.getVisibility() == View.INVISIBLE &&
                iv_23.getVisibility() == View.INVISIBLE && iv_24.getVisibility() == View.INVISIBLE &&
                iv_31.getVisibility() == View.INVISIBLE && iv_32.getVisibility() == View.INVISIBLE &&
                iv_33.getVisibility() == View.INVISIBLE && iv_34.getVisibility() == View.INVISIBLE &&
                iv_41.getVisibility() == View.INVISIBLE && iv_42.getVisibility() == View.INVISIBLE &&
                iv_43.getVisibility() == View.INVISIBLE && iv_44.getVisibility() == View.INVISIBLE &&
                iv_51.getVisibility() == View.INVISIBLE && iv_52.getVisibility() == View.INVISIBLE &&
                iv_53.getVisibility() == View.INVISIBLE && iv_54.getVisibility() == View.INVISIBLE) {

            //caso de perca
            if(pontosPc > Seuspontos){
                Intent i = new Intent(getContext(), gameOver.class);
                startActivity(i);
            }

            //caso de empate
            else if(pontosPc == Seuspontos){


                if(rodando){ //para o cronometro
                    tm.cancel();
                    rodando = false;

                    cont = 0;
                    tempoGame.setText("Tempo total gasto: "+ String.format("%02d:%02d:%02d", hrs, min, seg));
                    bestTimes.setText(frase);
                    res.setText("Deu empate!!!");

                }
                mostraRes();

            }

            //caso vença
            else if(Seuspontos > pontosPc){


                if(rodando){ //para o cronometro
                    tm.cancel();
                    rodando = false;

                    cont = 0;
                    tempoGame.setText("Tempo total gasto: "+ String.format("%02d:%02d:%02d", hrs, min, seg));
                    bestTimes.setText(frase);
                    res.setText("Você venceu!!!");

                }
                mostraRes();

            }




        }
    }


    private void CarregaCartas () {
        img101 = R.drawable.img_1;
        img102 = R.drawable.img_3;
        img103 = R.drawable.img_5;
        img104 = R.drawable.img_7;
        img105 = R.drawable.img_9;
        img106 = R.drawable.img_11;
        img107 = R.drawable.img_13;
        img108 = R.drawable.img_15;
        img109 = R.drawable.img_17;
        img110 = R.drawable.img_19;

        img201 = R.drawable.img_2;
        img202 = R.drawable.img_4;
        img203 = R.drawable.img_6;
        img204 = R.drawable.img_8;
        img205 = R.drawable.img_10;
        img206 = R.drawable.img_12;
        img207 = R.drawable.img_14;
        img208 = R.drawable.img_16;
        img209 = R.drawable.img_18;
        img210 = R.drawable.img_20;


    }


}






