package com.example.catris;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;


public class login extends AppCompatActivity {

    private Button btnIn;
    private TextView txtDireciona;
    private TextView txtNomeL;
    private String nomeStr;
    private String senhaStr;
    private TextView txtSenha;
    private TextView lblAviso2;
    private Usuario user;
    private TextView lblUsername;
    Cursor cursor2;
    Cursor cursor3;
    SQLiteDatabase bd2;
    Bundle bundle;


    @Override
    protected void onCreate(Bundle savedInstanceState) {


        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_login);
        btnIn = (Button) findViewById(R.id.btnIrLogin);
        txtDireciona = (TextView) findViewById(R.id.lblDirecionaCadastro);
        txtNomeL = findViewById(R.id.txtUserLogin);
        txtSenha = findViewById(R.id.txtSenhaLogin);
        lblAviso2 = findViewById(R.id.lblAviso2);

        lblUsername = findViewById(R.id.lblUsername);

        btnIn.setOnClickListener(new EscutadorBotaoPerfil());
        txtDireciona.setOnClickListener(new EscutadorDirecionaCadastro());

        bd2 = openOrCreateDatabase("xxx", MODE_PRIVATE, null);


    }

    private class EscutadorBotaoPerfil implements View.OnClickListener {

        @Override
        public void onClick(View view) {

            Button bu = (Button) view;
            nomeStr = txtNomeL.getText().toString();
            senhaStr = txtSenha.getText().toString();
            Usuario u = new Usuario(nomeStr, "", senhaStr);
            boolean achou = false;

            if(nomeStr.isEmpty() || senhaStr.isEmpty()){
                lblAviso2.setText("Preencha todos os campos");
            }else{
                String cmd = "SELECT nome, email, senha FROM user WHERE nome = ?";
                cursor2 = bd2.rawQuery(cmd, new String[] {nomeStr});
                String cmd2 = "SELECT nome, email, senha FROM user WHERE senha = ?";
                cursor3 = bd2.rawQuery(cmd2, new String[] {senhaStr});

                    if(cursor3.moveToNext() && cursor2.moveToNext()){
                            lblAviso2.setText("Login realizado com sucesso!");
                            Intent i = new Intent(getApplicationContext(), perfil.class);
                            i.putExtra("Chave", u.getUserName());
                            startActivity(i);


                    }else{
                        lblAviso2.setText("Senha/usuario incorretos ou nao cadastrados");
                    }


                }
            }





        }


    private class EscutadorDirecionaCadastro implements View.OnClickListener {
        @Override
        public void onClick(View view) {
            TextView txt = (TextView) view;

            Intent ica = new Intent(getApplicationContext(), MainActivity.class);
            startActivity(ica);
        }
    }




}