package com.example.catris;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.Toast;

public class ppModoClaro extends AppCompatActivity {

    private Button btnIniciarMC;
    private ImageView txtTroca;

    private ImageView perfilMC;
    private ImageView confiMC;

    private FrameLayout placeholderMC;
    private FrameLayout placeholderDados2;

    private String valor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pp_modo_claro);

        placeholderMC = findViewById(R.id.placeholderMC);


        txtTroca = findViewById(R.id.imgTrocaN);

        valor = getIntent().getStringExtra("chaveChbMC");


        perfilMC= findViewById(R.id.imgProfilppClaro);
        confiMC = findViewById(R.id.imgConfigppClaro);

        perfilMC.setOnClickListener(new DirecionaPerfilC());
        confiMC.setOnClickListener(new DirecionaConfigC());

        txtTroca.setOnClickListener(new EscutadorBotaoTroca2());


        btnIniciarMC = findViewById(R.id.btnIniciarMC);
        btnIniciarMC.setOnClickListener( new EscutadorBotaoPlayJogoMC() );
    }

    private class EscutadorBotaoTroca2 implements View.OnClickListener {
        @Override
        public void onClick(View view) {
            Intent i = new Intent(getApplicationContext(), ppNoturno.class);
            startActivity(i);
        }
    }



    private class DirecionaPerfilC implements View.OnClickListener {
        @Override
        public void onClick(View view) {
            Intent pe = new Intent(getApplicationContext(), perfil.class);
            startActivity(pe);
        }
    }

    private class DirecionaConfigC implements View.OnClickListener {
        @Override
        public void onClick(View view) {
            Intent co = new Intent(getApplicationContext(), config.class);
            startActivity(co);
        }
    }

    private class EscutadorBotaoPlayJogoMC implements View.OnClickListener {
        @Override
        public void onClick(View view) {

            if(valor == null){

                Toast.makeText(getApplicationContext(), "Fase: 3x4 (default)", Toast.LENGTH_SHORT).show();

                placeholderMC.removeAllViews();

                FragmentManager fm1 = getSupportFragmentManager();

                ImgsFragment3x4 tf = new ImgsFragment3x4();


                FragmentTransaction ft1 = fm1.beginTransaction();


                ft1.replace(R.id.placeholderMC, tf );


                ft1.commit();
            }else if(valor.equals("3x4Facil")){


                Toast.makeText(getApplicationContext(), "Fase: 3 x 4 - Dificuldade nível fácil", Toast.LENGTH_SHORT).show();

                placeholderMC.removeAllViews();

                FragmentManager fm1 = getSupportFragmentManager();

                ImgsFragment3x4 tf = new ImgsFragment3x4();


                FragmentTransaction ft1 = fm1.beginTransaction();


                ft1.replace(R.id.placeholderMC, tf );

            }else if(valor.equals("4x5Medio")){

                Toast.makeText(getApplicationContext(), "Fase: 4 x 5 - Dificuldade nível médio", Toast.LENGTH_SHORT).show();
                placeholderMC.removeAllViews();

                FragmentManager fm1 = getSupportFragmentManager();

                FragmentTransaction ft = fm1.beginTransaction();

                ft.replace(R.id.placeholderMC, new ImgsFragment4x5());
                ft.commit();


            }else if(valor.equals("5x6Dificil")) {

                Toast.makeText(getApplicationContext(), "Fase: 5 x 6 - Dificuldade nível difícil", Toast.LENGTH_SHORT).show();
                placeholderMC.removeAllViews();

                FragmentManager fm1 = getSupportFragmentManager();

                FragmentTransaction ft = fm1.beginTransaction();

                ft.replace(R.id.placeholderMC, new ImgsFragment5x6());
                ft.commit();

             }else if(valor.equals("3x4Survival")){

                Toast.makeText(getApplicationContext(), "Fase: 3 x 4 no modo Sobrevivência! Tempo limite de 20s", Toast.LENGTH_SHORT).show();
                placeholderMC.removeAllViews();

                FragmentManager fm1 = getSupportFragmentManager();

                FragmentTransaction ft = fm1.beginTransaction();

                ft.replace(R.id.placeholderMC, new ImgsFragment3x4_MSV());
                ft.commit();



            }else if(valor.equals("4x5Survival")){

                Toast.makeText(getApplicationContext(), "Fase: 4 x 5 no modo Sobrevivência! Tempo limite de 40s", Toast.LENGTH_SHORT).show();
                placeholderMC.removeAllViews();

                FragmentManager fm1 = getSupportFragmentManager();

                FragmentTransaction ft = fm1.beginTransaction();

                ft.replace(R.id.placeholderMC, new ImgsFragment4x5_MSV());
                ft.commit();


            }else if(valor.equals("5x6Survival")){
                Toast.makeText(getApplicationContext(), "Fase: 5 x 6 no modo Sobrevivência! Tempo limite de 60s", Toast.LENGTH_SHORT).show();

                placeholderMC.removeAllViews();

                FragmentManager fm1 = getSupportFragmentManager();

                FragmentTransaction ft = fm1.beginTransaction();

                ft.replace(R.id.placeholderMC, new ImgsFragment5x6_MSV());
                ft.commit();
            }



        //-------------------------------------------------------------




        }
    }

}