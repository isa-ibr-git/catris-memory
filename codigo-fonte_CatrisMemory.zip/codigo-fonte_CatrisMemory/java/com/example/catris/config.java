package com.example.catris;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.TextView;

public class config extends AppCompatActivity {

    private Button btnPlay2;
    private ImageView perfil;
    private String v, v2;
    private CheckBox chb3x4, chb4x5, chb5x6;
    private CheckBox chb3x4SM, chb4x5SM, chb5x6SM;

    private String chbOpc = "";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_config);

        btnPlay2 = (Button) findViewById(R.id.btnIrLogin);
        btnPlay2.setOnClickListener(new EscutadorBotaoPlay());

        perfil = (ImageView) findViewById(R.id.imgProfil);
        perfil.setOnClickListener(new EscutadorPerfil());

        chb3x4 = (CheckBox) findViewById(R.id.chb3x4);
        chb4x5 = (CheckBox) findViewById(R.id.chb4x5);
        chb5x6 = (CheckBox) findViewById(R.id.chb5x6);

        chb3x4SM = (CheckBox) findViewById(R.id.chb3x4SM);
        chb4x5SM = (CheckBox) findViewById(R.id.chb4x5SM);
        chb5x6SM = (CheckBox) findViewById(R.id.chb5x6SM);



        chb3x4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                chb4x5.setChecked(false);
                chb5x6.setChecked(false);
                chb3x4SM.setChecked(false);
                chb4x5SM.setChecked(false);
                chb5x6SM.setChecked(false);
                chbOpc = "3x4Facil";
            }
        });

        chb4x5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                chb3x4.setChecked(false);
                chb5x6.setChecked(false);
                chb3x4SM.setChecked(false);
                chb4x5SM.setChecked(false);
                chb5x6SM.setChecked(false);
                chbOpc = "4x5Medio";
            }
        });

        chb5x6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                chb3x4.setChecked(false);
                chb4x5.setChecked(false);
                chb3x4SM.setChecked(false);
                chb4x5SM.setChecked(false);
                chb5x6SM.setChecked(false);
                chbOpc = "5x6Dificil";
            }
        });

        chb3x4SM.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                chb3x4.setChecked(false);
                chb4x5.setChecked(false);
                chb5x6.setChecked(false);
                chb4x5SM.setChecked(false);
                chb5x6SM.setChecked(false);
                chbOpc = "3x4Survival";
            }
        });

        chb4x5SM.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                chb3x4.setChecked(false);
                chb4x5.setChecked(false);
                chb5x6.setChecked(false);
                chb3x4SM.setChecked(false);
                chb5x6SM.setChecked(false);
                chbOpc = "4x5Survival";
            }
        });

        chb5x6SM.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                chb3x4.setChecked(false);
                chb4x5.setChecked(false);
                chb5x6.setChecked(false);
                chb3x4SM.setChecked(false);
                chb4x5SM.setChecked(false);
                chbOpc = "5x6Survival";
            }
        });

    }

    private class EscutadorBotaoPlay implements View.OnClickListener {
        @Override
        public void onClick(View view) {
            Button b = (Button) view;
            Intent i = new Intent( getApplicationContext(), ppNoturno.class );
            i.putExtra("chaveChb", chbOpc ); //mandando o check pro jogo no modo noturno




            startActivity(i);
        }


    }

    private class EscutadorPerfil implements View.OnClickListener {
        @Override
        public void onClick(View view) {

            Intent p = new Intent( getApplicationContext(), perfil.class );

            startActivity(p);


        }


    }


}