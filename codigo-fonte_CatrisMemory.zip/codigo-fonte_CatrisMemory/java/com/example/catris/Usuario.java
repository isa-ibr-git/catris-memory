package com.example.catris;

public class Usuario {
    private String email;
    private String senha;
    private String userName;
    private String bestTimes;
    private String Sprint44;
    private String Sprint99;
    private String Sprint1616;
    private String SV;


    public Usuario(String userName, String email, String senha) {
        this.email = email;
        this.senha = senha;
        this.userName = userName;
    }




    public String getEmail() {
        return email;
    }

    public String getSenha() {
        return senha;
    }

    public String getUserName() {
        return userName;
    }

    public String getBestTimes() {
        return bestTimes;
    }

    public String getSprint44() {
        return Sprint44;
    }

    public String getSprint99() {
        return Sprint99;
    }

    public String getSprint1616() {
        return Sprint1616;
    }

    public String getSV() {
        return SV;
    }

    public void setBestTimes(String bestTimes) {
        this.bestTimes = bestTimes;
    }

    public void setSprint44(String sprint44) {
        Sprint44 = sprint44;
    }

    public void setSprint99(String sprint99) {
        Sprint99 = sprint99;
    }

    public void setSprint1616(String sprint1616) {
        Sprint1616 = sprint1616;
    }

    public void setSV(String SV) {
        this.SV = SV;
    }
}
