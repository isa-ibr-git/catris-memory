package com.example.catris;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class gameOver extends AppCompatActivity {

    private Button btnC, btnP, btnV;
    private String chave;
    private TextView resultado;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game_over);

        btnC = (Button) findViewById(R.id.btnConfig);
        btnP = (Button) findViewById(R.id.btnPerfil);
        btnV = (Button) findViewById(R.id.btnVolta);
        resultado = findViewById(R.id.txtChave);


        btnC.setOnClickListener(new EscutadorBotaoConfig());
        btnP.setOnClickListener(new EscutadorBotaoPerfil());
        btnV.setOnClickListener(new EscutadorBotaoVolta());
    }

    private class EscutadorBotaoVolta implements View.OnClickListener {
        @Override
        public void onClick(View view) {
            Button b = (Button) view;
            Intent i = new Intent( getApplicationContext(), ppNoturno.class );
            startActivity(i);
        }


    }

    private class EscutadorBotaoPerfil implements View.OnClickListener {
        @Override
        public void onClick(View view) {

            Intent p = new Intent( getApplicationContext(), perfil.class );
            startActivity(p);
        }


    }

    private class EscutadorBotaoConfig implements View.OnClickListener {
        @Override
        public void onClick(View view) {

            Intent c = new Intent( getApplicationContext(), config.class );
            startActivity(c);
        }


    }


}