package com.example.catris;

public class UserJoga {
    private String nomeUser;
    private int idGame;
    private String melhorTempo;

    public UserJoga(String nomeUser, int idGame, String melhorTempo) {
        this.nomeUser = nomeUser;
        this.idGame = idGame;
        this.melhorTempo = melhorTempo;
    }

    public String getMelhorTempo() {
        return melhorTempo;
    }

    public void setMelhorTempo(String melhorTempo) {
        this.melhorTempo = melhorTempo;
    }
}
