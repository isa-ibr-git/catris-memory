package com.example.catris;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.util.ArrayList;

public class MainActivity<SQLLite> extends AppCompatActivity {

    private Button btnCadastro;
    private TextView txtDireciona;
    private TextView userName;
    private TextView email;
    private TextView senha;
    private TextView lblAviso;
    private String userNameStr;
    private String emailStr;
    private String senhaLoginStr;
    private Usuario user;
    private Game game;
    Cursor cursor;
    private ArrayList<Usuario> listaUsuarios = new ArrayList<>();
    private ArrayList<String> nomes = new ArrayList<>();
    boolean achou = false;

    ArrayList<String> cadastro = new ArrayList<>();

    SQLiteDatabase bd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnCadastro = (Button) findViewById(R.id.btnCadastro);
        txtDireciona = (TextView) findViewById(R.id.lblDirecionaLogin);
        userName = findViewById(R.id.txtUser);
        email = findViewById(R.id.txtNome);
        senha = findViewById(R.id.txtSenha);
        lblAviso = findViewById(R.id.lblAviso);

        btnCadastro.setOnClickListener(new EscutadorBotao());
        txtDireciona.setOnClickListener(new EscutadorDireciona());

        bd = openOrCreateDatabase("xxx", MODE_PRIVATE, null);
        bd.execSQL("Create table if not exists user(nome PRIMARY KEY, email varchar, senha varchar)");

        bd.execSQL("Create table if not exists game(idGame INTEGER, tipo varchar)");

        bd.execSQL("Create table if not exists rel_joga(id INTEGER PRIMARY KEY Autoincrement, nomeUser varchar, idJogo INTEGER, melhorTempo INTEGER)");



        //Pré Inserções de fases

        bd.execSQL("INSERT INTO game(idGame, tipo) VALUES ('" + 1 + "', '" + "3x4Facil" + "')");
        bd.execSQL("INSERT INTO game(idGame, tipo) VALUES ('" + 2 + "', '" + "4x5Medio" + "')");
        bd.execSQL("INSERT INTO game(idGame, tipo) VALUES ('" + 3 + "', '" + "5x6Dificil" + "')");

        bd.execSQL("INSERT INTO game(idGame, tipo) VALUES ('" + 10 + "', '" + "3x4Survival" + "')");
        bd.execSQL("INSERT INTO game(idGame, tipo) VALUES ('" + 20 + "', '" + "4x5Survival" + "')");
        bd.execSQL("INSERT INTO game(idGame, tipo) VALUES ('" + 30 + "', '" + "5x6Survival" + "')");




        //---------------------------------------------------



        cursor = bd.rawQuery("Select nome, email, senha FROM user", null);
        cursor = bd.rawQuery("Select idGame, tipo FROM game", null);
        cursor = bd.rawQuery("Select _rowid_ _id, nomeUser, idJogo, melhorTempo FROM rel_joga", null);



        //intent.putExtra("nomeG", c.getString(c.getColumnIndex("nomeG")));
    }




    private class EscutadorBotao implements View.OnClickListener {
        @Override
        public void onClick(View view) {
            Usuario u1 = new Usuario("apokkois", "uuippo", "llllllao");

            if (userName.getText().toString().isEmpty() || email.getText().toString().isEmpty() || senha.getText().toString().isEmpty()) {
                lblAviso.setText("Preencha todos os campos, por favor");
            } else {
                userNameStr = userName.getText().toString();
                emailStr = email.getText().toString();
                senhaLoginStr = senha.getText().toString();




                boolean vazio = false;

                boolean in = true;


                String cmd = "SELECT nome, email, senha FROM user WHERE nome = ?";
                cursor = bd.rawQuery(cmd, new String[] { userNameStr});
                    if (cursor.moveToNext()) {
                        achou = true;
                        lblAviso.setText("Esse nome de usuário já existe");

                    }else {

                        Usuario u = new Usuario(userNameStr, emailStr, senhaLoginStr);


                        listaUsuarios.add(u);
                        nomes.add(userNameStr);

                        bd.execSQL("INSERT INTO user (nome, email, senha) VALUES ('" + userNameStr + "', '" + emailStr + "', '" + senhaLoginStr + "')");


                        //colocando o usuario em todos os niveis

                        bd.execSQL("INSERT INTO rel_joga(nomeUser, idJogo, melhorTempo) VALUES ('" + userNameStr + "', '" + 1 + "', '" + 1000000 +"')");
                        bd.execSQL("INSERT INTO rel_joga(nomeUser, idJogo, melhorTempo) VALUES ('" + userNameStr + "', '" + 2 + "', '" + 1000000 + "')");
                        bd.execSQL("INSERT INTO rel_joga(nomeUser, idJogo, melhorTempo) VALUES ('" + userNameStr + "', '" + 3 + "',  '" + 1000000 + "')");

                        bd.execSQL("INSERT INTO rel_joga(nomeUser, idJogo, melhorTempo) VALUES ('" + userNameStr + "', '" + 10 + "',  '" + 1000000 + "')");
                        bd.execSQL("INSERT INTO rel_joga(nomeUser, idJogo, melhorTempo) VALUES ('" + userNameStr + "', '" + 20 + "',  '" + 1000000 + "')");
                        bd.execSQL("INSERT INTO rel_joga(nomeUser, idJogo, melhorTempo) VALUES ('" + userNameStr + "', '" + 30 + "',  '" + 1000000 + "')");



                        userName.setText("");
                        email.setText("");
                        senha.setText("");

                        cursor = bd.rawQuery("Select nome, email, senha FROM user", null);

                        lblAviso.setText("Cadastro realizado com sucesso!");


                        Intent i = new Intent(getApplicationContext(), login.class);
                        startActivity(i);
                    }



            }


            new Handler().postDelayed(new Runnable() {
                @Override
                public void run() {
                    lblAviso.setText("");
                }
            }, 3000);
        }

        }

    private class EscutadorDireciona implements View.OnClickListener {
        @Override
        public void onClick(View view) {
            TextView t = (TextView) view;

            Intent l = new Intent( getApplicationContext(), login.class );
            startActivity(l);
        }


    }




}
