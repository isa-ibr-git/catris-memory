package com.example.catris;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class perfil extends AppCompatActivity {

    private Button btnSair;
    private Button btnPlayGame;
    private ImageView imgConf;
    private TextView username;
    private TextView lblTempo1;
    private TextView lblTempo2;
    private TextView lblTempo3;
    public String valor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_perfil);


        //Definindo os dados de acordo com o login
        username = findViewById(R.id.lblUsername);

        valor = getIntent().getStringExtra("Chave");
    

        username.setText(valor);






        btnSair = (Button) findViewById(R.id.btnSair);
        btnSair.setOnClickListener(new EscutadorBotaoSai());

        btnPlayGame = (Button) findViewById(R.id.btnPlayGame);
        btnPlayGame.setOnClickListener(new EscutadorBotaoPG());

        imgConf = (ImageView) findViewById(R.id.imgConfig);
        imgConf.setOnClickListener(new EscutadorAcessa());


    }

    private class EscutadorBotaoSai implements View.OnClickListener {
        @Override
        public void onClick(View view) {
            Button b = (Button) view;
            Intent iPp = new Intent(getApplicationContext(), login.class);
            startActivity(iPp);
        }

    }

    private class EscutadorBotaoPG implements View.OnClickListener {
        @Override
        public void onClick(View view) {
            Button b = (Button) view;
            Intent iPG = new Intent(getApplicationContext(), ppNoturno.class);
            startActivity(iPG);
        }

    }

    private class EscutadorAcessa implements View.OnClickListener {
        @Override
        public void onClick(View view) {

            Intent iAc = new Intent(getApplicationContext(), config.class);

            startActivity(iAc);
        }

    }
}